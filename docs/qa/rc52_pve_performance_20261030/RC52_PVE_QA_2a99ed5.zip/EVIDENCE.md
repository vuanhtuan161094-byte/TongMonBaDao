# RC52 PvE performance evidence

- Exact RC source commit: `2a99ed505c85a17f6d25f91891560ca51fa02d88` (PR #52 branch; not merged).
- Engine: Godot `4.7.2.stable.official.ed1daf0bf`; renderer: `Intel(R) Iris(R) Plus Graphics`.
- Focused matrix: 18/18 exit code 0. The Save A/B test emits expected validation diagnostics for deliberately invalid fixtures; its final marker reports `invalid_D7_fixture=true`, `last_good_primary_preserved=true`, `unresolved_defect=false`.
- Scripted GUI integration: six disciples, ten monsters; 120 shared-clock steps (127–129 battle seconds), 31 kills, 418–428 actions, zone hop PASS, active Save/Load PASS, no reward fabrication. Injury120 was not reached; loot remains pending.
- JX #158: cast, positive Combat V2 hit and visible on-map impact draw PASS. Screenshot is 1280x720. The AVI is delivered separately in the local output folder and is not included in this ZIP.
- Zoom: 0.80 and 1.35 draw-scale/ring tests PASS (measured minimum ring edge gap 13.56px and 39.04px in the capture run). Wheel and +/- were injected through the GUI harness; physical mouse acceptance remains PENDING because Computer Use did not expose the Godot window.

## Logger OFF / ON active-session frame data

Raw frame gaps from the two `phase_summary` records tagged `pve` and `pve_save` were combined. The probe's `pve_save` label stays active after the save confirmation text persists, so these rows represent the full active PVE session, including the save boundary. The OFF/ON runs used the same seed, fixture and 120 poll steps but differed by 2 simulated seconds and ~13 seconds of wall sampling; they are a matched fixture, not bit-identical wall traces.

| Logger | Frames | Mean ms | P50 ms | P95 ms | P99 ms | 1%-low FPS | Max ms | >100ms spikes | Godot static peak | Video memory peak |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| OFF | 3,281 | 17.23 | 16.65 | 18.64 | 44.30 | 12.45 | 369.47 | 4 | 189.5 MiB | 274.3 MiB |
| ON | 4,017 | 17.37 | 16.66 | 18.22 | 47.24 | 10.94 | 563.04 | 4 | 190.1 MiB | 274.3 MiB |

Mean FPS is about 58 in both runs; P95/P99 meet 33.3/50ms goals. The 1%-low target of 40 FPS fails, and both runs contain four >100ms frame gaps. This is **not a PLAYABLE/PERFORMANCE PASS**.

PowerShell sampled the Godot process set during a third 120-step logger-OFF run: highest single process working set 991.16 MiB/private 943.64 MiB; two concurrent Godot PIDs were observed, with combined sampled working set peaking at 1,402.70 MiB. Godot's own static allocation peak was 190.1 MiB. This is process sampling for the controlled QA run, not a system-wide RAM benchmark.

The largest ON gaps (563, 330, 225ms) coincided with Godot process monitor values 74, 52, 53ms and physics values below 0.16ms. Internal measured recurring costs were poll <=2.303ms, refresh <=2.347ms, HUD <=2.267ms, snapshot <=0.030ms, VFX draw <=2.948ms. Formation pathfinding peaked at 75.348ms once; production actor sync peaked at 86.439ms during scene transition. These do not explain the full frame gaps; the render/OS scheduling cause remains unconfirmed. No >100ms events repeated every 2 seconds in these traces.

## Acceptance gates

- PASS: exact-SHA focused regression; 120-step scripted active combat; six-vs-ten fixture; zone hop; Save/Load; JX #158 cast/hit/impact draw; 1280x720 gameplay and zoom captures.
- FAIL: frame-time objective due to 1%-low and >100ms hitches.
- PENDING: physical mouse/wheel/pan/selection, owner acceptance, real manual Save/Return/Reload. GUI capture is Godot-rendered and test-controlled, not a manual mouse session.
- PENDING: Injury120 was not reached in the 120-second fixture. No loot was created; status remains `LOOT_PENDING`.
